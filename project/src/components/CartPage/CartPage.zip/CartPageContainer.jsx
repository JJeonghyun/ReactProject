import CartPageComp from "./CartPageComp";

const CartPageContainer = () => {
  return <CartPageComp />;
};

export default CartPageContainer;
