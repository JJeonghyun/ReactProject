const CartPageComp = () => {
  return <div>asd</div>;
};

export default CartPageComp;
